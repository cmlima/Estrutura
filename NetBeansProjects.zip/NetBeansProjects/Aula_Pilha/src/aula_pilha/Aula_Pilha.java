/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula_pilha;

/**
 *
 * @author lab801
 */
public class Aula_Pilha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pilha pilha = new Pilha(10);
        
        System.out.println("isEmpty: " + pilha.isEmpty());
        System.out.println("isFull: " + pilha.isFull());
        System.out.println("size: " + pilha.size());
        System.out.println("push: " + pilha.push(10));
        System.out.println("push: " + pilha.push(20));
        System.out.println("push: " + pilha.push(30));
        System.out.println("push: " + pilha.push(40));
        System.out.println("push: " + pilha.push(50));
        System.out.println("push: " + pilha.push(60));
        System.out.println("push: " + pilha.push(70));
        System.out.println("push: " + pilha.push(80));
        System.out.println("push: " + pilha.push(90));
        System.out.println("push: " + pilha.push(100));
        System.out.println("push: " + pilha.push(110));
        System.out.println("push: " + pilha.push(120));
        System.out.println("size: " + pilha.size());
        System.out.println("isFull: " + pilha.isFull());
        System.out.println("peek: " + pilha.peek());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("pop: " + pilha.pop());
        System.out.println("size: " + pilha.size());
        System.out.println("isEmpty: " + pilha.isEmpty());
    }
    
}
